//
//  ViewController.swift
//  SaurabhPractical
//
//  Created by S@ur@bh on 12/9/19.
//  Copyright © 2019 S@ur@bh. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var txtName : UITextField!
    @IBOutlet var txtPass : UITextField!
    @IBOutlet var btnLogin : UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK : Textfield Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
       textField.resignFirstResponder()
       return true
    }
    
    //MARK : Login Button Action
    @IBAction func btnClicked(_ sender: Any)
    {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ExapandCellVC") as? ExapandCellVC
        self.navigationController?.pushViewController(vc!, animated: true)
        
        if (txtName.text?.isEmpty)!
        {
            ShowAlert(Message:"Enter E-mail")
        }
        else if !(isValidEmail(testStr: txtName.text!))
        {
            ShowAlert(Message:"Invalid Email")
        }
            
        else if(txtPass.text?.isEmpty)!
        {
            ShowAlert(Message:"Enter Password")
        }
        else
        {
            loginLoadData()
        }
    }
    
    //MARK : Login Webservice Load Data
    func loginLoadData()
    {
         let url = "http://mycare.xceltec.com/app/user/login"
       
       /* let parameters: Parameters = [
                          "userid": "trupen@xceltec.in","password" : "Tcl806**","deviceid" : "d12342","role" : "2","fcmtoken" : "fcm12342"]*/
               let parameters: [String : AnyObject] = [
                       "userid": txtName.text as AnyObject,"password" : txtPass.text as AnyObject,"deviceid" : "d12342" as AnyObject,"role" : "2" as AnyObject,"fcmtoken" : "fcm12342" as AnyObject]

                      Alamofire.request(url, method:.post, parameters:parameters).responseJSON { response in
                          switch response.result {
                          case .success:
                              print(response)
                           let responseObject = response.result.value as! Dictionary<String, Any>
                           let statusCode = responseObject["code"] as! Int
                           if statusCode == 200 {
                               let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ExapandCellVC") as? ExapandCellVC
                               self.navigationController?.pushViewController(vc!, animated: true)
                               
                           } else{
                            self.ShowAlert(Message:(responseObject["message"] as? String)!)
                           }
                              
                          case .failure(let error):
                              print(error)
                              self.ShowAlert(Message:error as! String)
                          }
                          
                      }
    }
    
    //MARK : Valid Email Function
    func isValidEmail(testStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }

    //MARK : Alert Function
    func ShowAlert (Message:String)
    {
        let alert = UIAlertController(title: "Alert", message: Message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}





